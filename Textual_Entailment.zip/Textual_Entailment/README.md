## Code Description

    File Name : DecisionTree.ipynb
    File Description : Code to train and evaluate the Decision Tree model

    File Name :navie_bayes.ipynb
    File Description : Code to train and evaluate the naive bayes model
    
    File Name :lstm.ipynb
    File Description : Code to train and evaluate the LSTM model

    File Name : Transformers.ipynb
    File Description : Code to train and evaluate the Transformers model

    The data in the data folder needs to be unpacked before running the code.